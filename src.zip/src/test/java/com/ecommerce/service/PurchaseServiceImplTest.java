package com.ecommerce.service;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.OrderHistory;
import com.ecommerce.entity.Product;
import com.ecommerce.feign.BankClient;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.OrderHistoryRepository;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class PurchaseServiceImplTest {

    @Mock
    private CartItemRepository cartRepo;

    @Mock
    private BankClient bankClient;

    @Mock
    private OrderHistoryRepository orderRepo;

    @InjectMocks
    private PurchaseServiceImpl purchaseService;

    @Test
    void testPlaceOrder_Success() {
        Long userId = 1L;
        String accountNumber = "123456";

        CartItem item = new CartItem();
       
        item.setQuantity(2);

        Mockito.when(cartRepo.findByUserId(userId)).thenReturn(List.of(item));
        Mockito.when(bankClient.transfer(Mockito.eq(accountNumber), Mockito.anyString(), Mockito.anyDouble()))
               .thenReturn("Transfer successful");

        String result = purchaseService.placeOrder(userId, accountNumber);

        assertEquals("Order Placed Successfully. Amount Debited.", result);
        Mockito.verify(orderRepo).save(Mockito.any(OrderHistory.class));
    }
}
