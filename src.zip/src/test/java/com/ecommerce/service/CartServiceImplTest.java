package com.ecommerce.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.Product;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.ProductRepository;
import com.google.common.base.Optional;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)

public class CartServiceImplTest {

    @Mock
    private CartItemRepository cartRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private CartServiceImpl cartService;

    @Test
    void testAddToCart() {
        Long userId = 1L;
        Long productId = 101L;
        int quantity = 2;

        Product product = new Product();
        product.setId(productId);
        product.setPrice(100.0);

     
        CartItem cartItem = new CartItem();
        cartItem.setQuantity(quantity);
        cartItem.setUserId(userId);

        Mockito.when(cartRepository.save(Mockito.any(CartItem.class))).thenReturn(cartItem);

        CartItem result = cartService.addToCart(cartItem) ; 
        assertNotNull(result);
        assertEquals(userId, result.getUserId());
        assertEquals(quantity, result.getQuantity());
    }
}
