package com.ecommerce.service;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.ProductRepository;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;



@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class ProductServiceImplTest {

    @InjectMocks
    private ProductServiceImpl productService;

    @Mock
    private ProductRepository productRepository;

    @Test
    void testGetProductById_success() {
        Product product = new Product();
        product.setId(1L);
        product.setPrice(500.0);

        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        Product result = productService.getProductById(1L);

        assertNotNull(result);
        assertEquals(500.0, result.getPrice());
    }

    @Test
    void testGetProductById_notFound() {
        when(productRepository.findById(2L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            productService.getProductById(2L);
        });

        assertEquals("Product not found", exception.getMessage());
    }
}
