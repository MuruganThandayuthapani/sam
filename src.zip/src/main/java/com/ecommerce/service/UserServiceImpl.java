package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
@Service
public class UserServiceImpl  implements UserService{

	 @Autowired
	    private UserRepository userRepo;

	    @Override
	    public User register(User user) {
	        return userRepo.save(user);
	    }

	    @Override
	    public String login(String email, String password) {
	        return userRepo.findByEmail(email)
	                .filter(u -> u.getPassword().equals(password))
	                .map(u -> "Login Successful!")
	                .orElse("Invalid credentials");
	    }


}
