package com.ecommerce.service;

import java.util.List;

import com.ecommerce.entity.CartItem;

public interface CartService {
	  CartItem addToCart(CartItem cartItem);
	    List<CartItem> getCartByUserId(Long userId);
	    void removeFromCart(Long cartItemId);
}
