package com.ecommerce.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.OrderHistory;
import com.ecommerce.entity.Product;
import com.ecommerce.feign.BankClient;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.OrderHistoryRepository;
import com.ecommerce.repository.ProductRepository;

@Service
public class PurchaseServiceImpl implements PurchaseService {
	 @Autowired
	    private CartItemRepository cartRepo;

	    @Autowired
	    private BankClient bankClient;

	    @Autowired
	    private OrderHistoryRepository orderRepo;
	    
	    @Autowired
	    private ProductRepository productRepo;
	    
	    @Override
	    public String placeOrder(Long userId, String accountNumber) {
	        List<CartItem> cartItems = cartRepo.findByUserId(userId);

	        if (cartItems.isEmpty()) {
	            return "Cart is empty";
	        }

	        double totalAmount = 0;

	        for (CartItem item : cartItems) {
	            Optional<Product> productOpt = productRepo.findById(item.getProductId());
	            if (productOpt.isEmpty()) {
	                return "Product with ID " + item.getProductId() + " not found.";
	            }

	            Product product = productOpt.get();
	            double itemTotal = product.getPrice() * item.getQuantity();
	            totalAmount += itemTotal;
	        }

	        String bankResponse = bankClient.transfer(accountNumber, "9999999999", totalAmount);

	        OrderHistory order = new OrderHistory();
	        order.setUserId(userId);
	        order.setDate(LocalDate.now());
	        order.setTotalAmount(totalAmount);

	        if (bankResponse.contains("successful")) {
	            order.setStatus("SUCCESS");
	            orderRepo.save(order);
	            cartRepo.deleteAll(cartItems);
	            return "Order Placed Successfully. Amount Debited: "+totalAmount;
	        } else {
	            order.setStatus("FAILED");
	            orderRepo.save(order);
	            return "Order Failed. " + bankResponse;
	        }
	    }
}
