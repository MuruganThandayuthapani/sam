package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	 @Autowired
	    private ProductRepository productRepo;

	    @Override
	    public Product addProduct(Product product) {
	        return productRepo.save(product);
	    }

	    @Override
	    public List<Product> getAllProducts() {
	        return productRepo.findAll();
	    }

	    @Override
	    public Product getProductById(Long id) {
	        return productRepo.findById(id)
	                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
	    }
}
