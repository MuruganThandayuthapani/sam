package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.CartItem;
import com.ecommerce.repository.CartItemRepository;
@Service
public class CartServiceImpl implements CartService{
	 @Autowired
	    private CartItemRepository cartRepo;

	    @Override
	    public CartItem addToCart(CartItem cartItem) {
	    	
	        return cartRepo.save(cartItem);
	    }

	    @Override
	    public List<CartItem> getCartByUserId(Long userId) {
	        return cartRepo.findByUserId(userId);
	    }

	    @Override
	    public void removeFromCart(Long cartItemId) {
	        cartRepo.deleteById(cartItemId);
	    }
	    
}
