package com.ecommerce.service;

import com.ecommerce.entity.User;

public interface UserService {
	 User register(User user);
	 String login(String email, String password);
}
