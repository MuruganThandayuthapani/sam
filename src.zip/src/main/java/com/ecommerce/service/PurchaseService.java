package com.ecommerce.service;

public interface PurchaseService {

	String placeOrder(Long userId, String accountNumber);
}
