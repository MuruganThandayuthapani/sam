package com.ecommerce.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "bank-client", url = "http://localhost:8081/api/bank")
//@FeignClient(name="http://localhost:8081/api/bank")
public interface BankClient {

    @PostMapping("/transfer")
    String transfer(@RequestParam String fromAccount,
                    @RequestParam String toAccount,
                    @RequestParam double amount);
}

