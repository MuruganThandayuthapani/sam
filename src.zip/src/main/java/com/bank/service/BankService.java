package com.bank.service;

import java.time.LocalDate;
import java.util.List;

import com.bank.entity.BankCustomer;
import com.bank.entity.Transaction;

public interface BankService {
	 	BankCustomer registerCustomer(BankCustomer customer);
	    String transferFunds(String fromAccount, String toAccount, double amount);
		List<Transaction> getStatement(String accountNumber, LocalDate fromDate, LocalDate toDate);

}
