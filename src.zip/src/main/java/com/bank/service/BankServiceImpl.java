package com.bank.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.entity.BankCustomer;
import com.bank.entity.Transaction;
import com.bank.repository.BankCustomerRepository;
import com.bank.repository.TransactionRepository;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	private BankCustomerRepository repository;
	
	@Autowired
	private TransactionRepository txnRepo;

	@Override
	public BankCustomer registerCustomer(BankCustomer customer) {
		customer.setAccountNumber(generateAccountNumber());
	    customer.setBalance(10000); // Default balance
	    return repository.save(customer);
	}
	
	private String generateAccountNumber() {
	    long number = (long)(Math.random() * 9_000_000_000L) + 1_000_000_000L;
	    return String.valueOf(number);
	}
	
		
	@Override
	public String transferFunds(String fromAccount, String toAccount, double amount) {
	    Optional<BankCustomer> fromOpt = repository.findByAccountNumber(fromAccount);
	    Optional<BankCustomer> toOpt = repository.findByAccountNumber(toAccount);

	    Transaction txn = new Transaction();
	    txn.setFromAccount(fromAccount);
	    txn.setToAccount(toAccount);
	    txn.setAmount(amount);
	    txn.setDate(LocalDate.now());

	    if (fromOpt.isEmpty() || toOpt.isEmpty()) {
	        txn.setStatus("FAILED - ACCOUNT NOT FOUND");
	        txnRepo.save(txn);
	        return txn.getStatus();
	    }

	    BankCustomer from = fromOpt.get();
	    BankCustomer to = toOpt.get();

	    if (from.getBalance() < amount) {
	        txn.setStatus("FAILED - INSUFFICIENT FUNDS");
	        txnRepo.save(txn);
	        return txn.getStatus();
	    }

	    from.setBalance(from.getBalance() - amount);
	    to.setBalance(to.getBalance() + amount);

	    repository.save(from);
	    repository.save(to);

	    txn.setStatus("SUCCESS");
	    txnRepo.save(txn);
	    return "Transfer successful";
	}

	@Override
	public List<Transaction> getStatement(String accountNumber, LocalDate fromDate, LocalDate toDate) {
		
		return txnRepo.findByFromAccountAndDateBetween(accountNumber, fromDate, toDate);
	}

}
