package com.bank.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.BankCustomer;
import com.bank.entity.Transaction;
import com.bank.repository.TransactionRepository;
import com.bank.service.BankService;

@RestController
@RequestMapping("/api/bank")
public class BankController {

	 	@Autowired
	    private BankService bankService;
	 	
	 	@Autowired
	 	private TransactionRepository txnRepo;

	    @PostMapping("/register")
	    public BankCustomer register(@RequestBody BankCustomer customer) {
	        return bankService.registerCustomer(customer);
	    }

	    @PostMapping("/transfer")
	    public String transfer(@RequestParam String fromAccount,
	                           @RequestParam String toAccount,
	                           @RequestParam double amount) {
	        return bankService.transferFunds(fromAccount, toAccount, amount);
	    }
	
	    @GetMapping("/statement")
	    public List<Transaction> getStatement(@RequestParam String accountNumber,
	                                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
	                                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate) {
	    	
	        return bankService.getStatement(accountNumber, fromDate, toDate);
	    }

}
