package com.bank.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.entity.Transaction;

import java.time.LocalDate;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
	List<Transaction> findByFromAccountAndDateBetween(String fromAccount, LocalDate fromDate, LocalDate toDate);
}
