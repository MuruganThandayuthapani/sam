package com.bank.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.entity.BankCustomer;

public interface BankCustomerRepository extends JpaRepository<BankCustomer, Long> {
	Optional<BankCustomer> findByAccountNumber(String accountNumber);

}
